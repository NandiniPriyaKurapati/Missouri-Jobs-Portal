﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.Security;
using System.Web.Profile;

//Created By Nandini Priya Kurapati
// ID: 700645541
// Server Side Remidiation Project

public partial class Admin_Page : System.Web.UI.Page
{
    //connection string for connection to DB
    private string connectionString = WebConfigurationManager.ConnectionStrings["Profile_DB"].ConnectionString;
    MembershipUserCollection users;//Creates a User collection and stores it to Users 
     

    protected void Page_Load(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;//sets the multiview to 0 
        users = Membership.GetAllUsers();//users variable stores all the Membership Users
    }
    protected void Java_Btn_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;//sets the multiview to 1

        Profile_lbl.Text = "Below are the selected Profiles for the Java Job based on our criteria. You can either call them or Email which are displayed in the table";

        //disconnected data access:

        //connection 

        //sql query using Joins to display the selected canditates in the page based on the creteria.
        string sqlstring = "SELECT DISTINCT a.Name,a.Email,a.Phone,b.JobDescrp,a.Technology,b.Jobexp,b.JobLocation";
        sqlstring += " FROM UserProfile a JOIN JobInfo b ON a.Technology ='Java' and b.Jobexp=a.Experience and b.Jobtech='Java'";

        //connection object

        SqlConnection adminConnection = new SqlConnection(connectionString);

        //command object

        SqlCommand AdminCommand = new SqlCommand(sqlstring, adminConnection);

        //data adapter

        SqlDataAdapter AdminDataAdapater = new SqlDataAdapter(AdminCommand);

        //local dataset object
        DataSet adminDataset = new DataSet();

        try
        {
        //errorhandling 
        AdminDataAdapater.Fill(adminDataset, "Shippers");

        }
        catch (Exception err)
        {
            //Populating error message to label
            Admin_label.Text = "Error in reading";
            Admin_label.Text += err.Message;

        }
        finally
        {
            //dataset filled and is available in the local memory

            //data binding for the grid view when only the query returns some rows else populates error message
            if (adminDataset.Tables.Count > 0)
            {
                Rslt_GridView.DataSource = adminDataset;
                Rslt_GridView.DataBind();
            }
            else
            {
                Admin_label.Text = "No records returned";
            }
            adminConnection.Close();
        }

       
    }
    protected void Net_Btn_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;//sets the multiview to 1

        //disconnected data access:

        //connection 

        Profile_lbl.Text = "Below are the selected Profiles for the .Net Job based on our criteria. You can either call them or Email which are displayed in the table";

        //sql query using Joins to display the selected canditates in the page based on the creteria.
        string sqlstring = "SELECT DISTINCT a.Name,a.Email,a.Phone,b.JobDescrp,a.Technology,b.Jobexp,b.JobLocation";
        sqlstring += " FROM UserProfile a JOIN JobInfo b ON a.Technology ='.Net' and b.Jobexp=a.Experience and b.Jobtech='.Net'";


        //connection object

        SqlConnection adminConnection = new SqlConnection(connectionString);

        //command object

        SqlCommand AdminCommand = new SqlCommand(sqlstring, adminConnection);

        //data adapter

        SqlDataAdapter AdminDataAdapater = new SqlDataAdapter(AdminCommand);

        //local dataset object
        DataSet adminDataset = new DataSet();

        try
        {
            //errorhandling 
            AdminDataAdapater.Fill(adminDataset, "Shippers");

        }
        catch (Exception err)
        {
            //Populating error message to label
            Admin_label.Text = "Error in reading";
            Admin_label.Text += err.Message;

        }
        finally
        {
            //dataset filled and is available in the local memory

            //data binding for the grid view
            //data binding for the grid view when only the query returns some rows else populates error message
            if (adminDataset.Tables.Count > 0)
            {
                Rslt_GridView.DataSource = adminDataset;
                Rslt_GridView.DataBind();
            }
            else
            {
                Admin_label.Text = "No records returned";
            }
            adminConnection.Close();
        }
    }
    protected void Cyber_Btn_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;

        //disconnected data access:

        //connection 
        //sql query using Joins to display the selected canditates in the page based on the creteria.
        string sqlstring = "SELECT DISTINCT a.Name,a.Email,a.Phone,b.JobDescrp,a.Technology,b.Jobexp,b.JobLocation";
               sqlstring += " FROM UserProfile a JOIN JobInfo b ON a.Technology ='Cyber Security' and b.Jobexp=a.Experience and b.Jobtech='Cyber Security'";

               Profile_lbl.Text = "Below are the selected Profiles for the Cyber Security Job based on our criteria. You can either call them or Email which are displayed in the table";


        SqlConnection adminConnection = new SqlConnection(connectionString);

        //command object

        SqlCommand AdminCommand = new SqlCommand(sqlstring, adminConnection);

        //data adapter

        SqlDataAdapter AdminDataAdapater = new SqlDataAdapter(AdminCommand);

        //local dataset object
        DataSet adminDataset = new DataSet();

        try
        {
            //errorhandling
            AdminDataAdapater.Fill(adminDataset, "Shippers");

        }
        catch (Exception err)
        {
            //Populating error message to label
            Admin_label.Text = "Error in reading";
            Admin_label.Text += err.Message;
        }
        finally
        {
            //dataset filled and is available in the local memory
            //data binding for the grid view
            //data binding for the grid view when only the query returns some rows else populates error message
            if (adminDataset.Tables.Count > 0)
            {
                Rslt_GridView.DataSource = adminDataset;
                Rslt_GridView.DataBind();
            }
            else
            {
                Admin_label.Text = "No records returned";
            }

            adminConnection.Close();
            
        }
    }

    protected void Inactive_Btn_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
            
        //populates the users data to list box 
        UsersListBox.DataSource = users;
        UsersListBox.DataBind();
        
        
    }




  // If a user is selected, show the properties for the selected user.


    protected void UsersListBox_SelectedIndexChanged(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;

        if (UsersListBox.SelectedItem != null)
        {
            //display the users to listbox
            MembershipUser u = users[UsersListBox.SelectedItem.Value];

            EmailLabel.Text = u.Email;
            NameLabel.Text = u.UserName.ToString();
           
            LastActivityDateLabel.Text = u.LastActivityDate.ToString();

            //calculating the inactive days to display it to admin so, that he can decide if he can delete user or not
            DateTime lastdate = u.LastLoginDate;
            DateTime nowtime = DateTime.Now;

            TimeSpan datediff = nowtime - lastdate;

            //rounding the date diff to 1.0
            Days_activity.Text = Math.Round(datediff.TotalDays, 0).ToString();


        }
    }
    protected void Delete_Btn_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;

        //delete the user if admin clicks delete button
        Membership.DeleteUser(NameLabel.Text);

        Admin_Inctive.Text = "User Deleted Successfully";
    }
}