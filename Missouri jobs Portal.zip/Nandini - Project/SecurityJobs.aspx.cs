﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

//Created By Nandini Priya Kurapati
// ID: 700645541
// Server Side Remidiation Project

public partial class SecurityJobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Applynow_Btn(object sender, EventArgs e)
    {
        //checks whether the username session is empty then redirects to login page else redirects to application page 
        if (Session["Username"] != null)
        {
            Response.Redirect("Application_Form.aspx");

        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }
}