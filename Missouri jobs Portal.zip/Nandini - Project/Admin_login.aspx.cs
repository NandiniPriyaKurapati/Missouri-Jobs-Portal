﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

//Created By Nandini Priya Kurapati
// ID: 700645541
// Server Side Remidiation Project

public partial class Admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Admin_login_Click(object sender, EventArgs e)
    {
        if ((Membership.ValidateUser(Txt_Admin.Text, txt_AdminPass.Text)) && (Txt_Admin.Text=="admin"))//validating manager login
        {

            Response.Redirect("Admin_Page.aspx");//if manager logins redirects to Job View Portal 

        }

        else
        {
            Errlbl.Text = "Only Admin Has Previlages to login to the system";//manager login error message
        }
    }
}