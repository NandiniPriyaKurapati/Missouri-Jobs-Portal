﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.Security;

//Created By Nandini Priya Kurapati
// ID: 700645541
// Server Side Remidiation Project

public partial class salaryEstimator : System.Web.UI.Page
{
    private string connectionString = WebConfigurationManager.ConnectionStrings["Profile_DB"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
    }


    protected void ShowBtn_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;

        //connection object
        SqlConnection con = new SqlConnection(connectionString);

        //select query
        string select = "SELECT * FROM SalaryEstimate WHERE Technology=@technology and Experience=@experience;";
        SqlCommand cmd = new SqlCommand(select, con);

        //adding parameters
        cmd.Parameters.AddWithValue("@technology", Tech_drpdwn.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@experience", Exp_Radio.SelectedItem.Text);

        //declaring a reader for data reading
        SqlDataReader reader;

        try
        {
            con.Open();//opening the connection
            reader = cmd.ExecuteReader();//executing the query

            reader.Read();

            //storing into variables
            string minsal = reader["MinSal"].ToString();
            string maxsal = reader["MaxSal"].ToString();
            string dtech = reader["DesiredTech"].ToString();
            Result_Label.Text = "According to Missouri Jobs R&D a "+"<b>"+Tech_drpdwn.SelectedItem.Text+"</b>"+" Developer with experience of ";
            Result_Label.Text += Exp_Radio.SelectedItem.Text+" has a minimum salary of "+"<b>"+"$"+minsal+"</b>"+" and a maximum salary of "+"<b>"+"$"+maxsal+"</b>";
            Result_Label.Text += " Desired Technologies for a career growth are " + "<b>" + dtech + "</b>"+".";
            graphimg.Src = reader["img"]+".jpg";//displaying graph image
            graphimg.Visible = true;
            reader.Close();
        }


        catch (Exception err)
        {
            lblResults.Text = "Error in reading";//populating error message
            lblResults.Text += err.Message;

        }
        finally
        {
            con.Close();//closing connection
        }
    }
}