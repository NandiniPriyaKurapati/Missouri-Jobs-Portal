﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SubmitPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //declaring a varaible to hold output

        string Submit;
        Submit = "Your Job Application for  " + "<b>"+ Request.QueryString["tech"] + "</b>" + " Job has been submitted successfully "  + "<b>"+ Request.QueryString["name"]+"</b>"; 
        Submit +=    " If your selected you will recieve a Email or Phone call from HR Team. ";
        //display  details;
        Submit_label.Text = Submit;
    }
}