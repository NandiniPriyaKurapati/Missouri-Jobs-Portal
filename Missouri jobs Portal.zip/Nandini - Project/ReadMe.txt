Missouri Job Portal - Server side remediation project

Created by:
Created By Nandini Priya Kurapati
ID: 700645541


Job Portal Functionalites:

1)Surf through the Java jobs or .Net Jobs or Security Jobs click on apply now if the user is already loggined it will redirect to application form else it will ask for a login of user to continue 

Sample user Logins:
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|Username: nandini         |  Username: jack        |   Username: john      | Admin Username: admin     
|Password: 123456          |  Password: 123456      |   Password: 123456    | Admin Password: admin
|                          |                        |                       | 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

2)Application form please fill your details and must upload a resume of .DOCX type it will save the document to resume folder of project root folder and detaisl are stored in a table.

3)Salary Estimator Page we can estmate the salary of IT developer based on the user Input.

4)Admin can login to the system and see the selected Java,.Net,Cyber Security profiles based on the Join query of selection criterion.

5)Admin can also check the user inactive days and delete them if he wants to delete the user.

 