﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.Security;

//Created By Nandini Priya Kurapati
// ID: 700645541
// Server Side Remidiation Project

public partial class Application_Form : System.Web.UI.Page
{
    //connection string to connect to DB
    private string connectionString = WebConfigurationManager.ConnectionStrings["Profile_DB"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Apply_Btn_Click(object sender, EventArgs e)
    {

        //insert query to insert values to table 
        string insertSQL;
        insertSQL = "INSERT INTO [UserProfile] (";
        insertSQL += "Name, Email, Phone, Location,";
        insertSQL += "Technology, Status, Experience,";
        insertSQL += "Relocate)"; 
        insertSQL += "VALUES (";
        insertSQL += "@uname, @email, @phone, ";
        insertSQL += "@location, @technology, @status, @experience, ";
        insertSQL += "@relocate)";

        //connection object
        SqlConnection con = new SqlConnection(connectionString);

        //command object
        SqlCommand cmd = new SqlCommand(insertSQL, con);


         //Add the parameters.
        cmd.Parameters.AddWithValue("@uname", txtFirst_Name.Text.ToString());
        cmd.Parameters.AddWithValue("@email", Txt_email.Text.ToString());
        cmd.Parameters.AddWithValue("@phone", Txt_Phn.Text.ToString());
        cmd.Parameters.AddWithValue("@location", Location_drp.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@technology", Tech_Drpdwm.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@status",status_radio.SelectedItem.Text );
        cmd.Parameters.AddWithValue("@experience", exp_dropdwn.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@relocate", relocate_radio.SelectedItem.Text);


        // Try to open the database and execute the update.
        int added = 0;

        //try catch for insert query
        try
        {
            con.Open();
            added = cmd.ExecuteNonQuery();
            Result_txt.Text = "Insert OK ";

        }
        catch (Exception err)
        {
            Result_txt.Text = "Error inserting record. ";
            Result_txt.Text += err.Message;
        }
        finally
        {
            con.Close();
        }
        //using query string
        //create the url for the next page, including the data for query
        
        if (Resume_upload.HasFile)
        {
            string fileName = txtFirst_Name.Text.ToString();//saving the resume with user name as file name
            Resume_upload.PostedFile.SaveAs(Server.MapPath("~/Resumes/") + fileName + ".doc");//saving to resume folder 
            Resume_lbl.Text = "Resume Upload Successful.";//populating success message
        }
        else
        {
            Resume_lbl.Text = "Please Upload your resume";
        }

        //using to querystring to sent the user to next page along with username and technology
        string urlstring = "SubmitPage.aspx?";
        urlstring += "name=" + txtFirst_Name.Text.ToString() + "&";
        urlstring += "tech=" + Tech_Drpdwm.SelectedItem.Text;

        //send the data to the next page using the string 

        Response.Redirect(urlstring);
    }
   
       
    
}
