﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.Security;

//Created By Nandini Priya Kurapati
// ID: 700645541
// Server Side Remidiation Project

public partial class Login : System.Web.UI.Page

{
    //creates Connectionstring for Connection to DB
    private string connectionString = WebConfigurationManager.ConnectionStrings["Profile_DB"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;//login page
    }

    protected void Signup_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;//sign-up page


    }

    protected void CreateUserWizard1_CreatedUser(object sender, EventArgs e)
    {
        if (!Roles.IsUserInRole("User"))
        {
            //Roles.AddUserToRole(this.CreateUserWizard1.UserName, "user");
            Response.Redirect("Login.aspx");
        }
    }

    protected void User_login_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(Txt_user.Text, txt_Pass.Text))//validating user login
        {
            Session["Username"] = Txt_user.Text;//saving to session varaible
            Response.Redirect("JavaJobs.aspx");//redirecting to profile pic page

        }

        else
        {
            Err_Label.Text = "Please Enter Valid User name or password";
        }
    }
}
